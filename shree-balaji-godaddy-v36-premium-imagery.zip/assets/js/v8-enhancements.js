
(function(){

  const root=document.documentElement, ebar=document.querySelector('.ebar'), mainNav=document.getElementById('mainNav');
  function syncHeaderMetrics(){
    if(ebar) root.style.setProperty('--ebar-h',ebar.getBoundingClientRect().height+'px');
    if(mainNav) root.style.setProperty('--nav-h',mainNav.getBoundingClientRect().height+'px');
  }
  syncHeaderMetrics();
  window.addEventListener('load',syncHeaderMetrics,{once:true});
  window.addEventListener('resize',syncHeaderMetrics,{passive:true});
  const menu=document.getElementById('mobMenu'), btn=document.getElementById('hbg');
  function closeMenu(){if(!menu||!btn)return;menu.classList.remove('open');btn.setAttribute('aria-expanded','false');document.body.style.overflow='';}
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu?.classList.contains('open')){closeMenu();btn.focus();}});
  document.addEventListener('click',e=>{if(menu?.classList.contains('open')&&!menu.contains(e.target)&&!btn?.contains(e.target))closeMenu();});
  if(btn) btn.addEventListener('click',()=>{setTimeout(()=>{const open=menu?.classList.contains('open');document.body.style.overflow=open?'hidden':'';btn.setAttribute('aria-expanded',String(!!open));},0)});
  document.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:'website_action',action:el.dataset.track,page:location.pathname});}));
})();
