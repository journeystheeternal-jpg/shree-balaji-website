// Shree Balaji Car Helpline conversion event helper.
// Add your Google tag / GTM container in the website head, then these data-track clicks will push useful events.
window.dataLayer = window.dataLayer || [];
document.addEventListener('click', function(e){
  var el = e.target.closest('[data-track]');
  if(!el) return;
  window.dataLayer.push({event: el.getAttribute('data-track'), link_url: el.href || '', link_text: (el.textContent || '').trim().slice(0,80)});
});
