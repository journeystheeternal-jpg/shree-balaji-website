
// ── PAGE ROUTER ──
function showPage(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const pg=document.getElementById('page-'+name);
  if(pg)pg.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  setTimeout(()=>{initReveal();}  ,80);
}

// ── NAV SCROLL ──
const nav=document.getElementById('mainNav');
const mobMenu=document.getElementById('mobMenu');
const syncHeaderState=()=>{
  nav.classList.toggle('scrolled',window.scrollY>50);
};
window.addEventListener('scroll',syncHeaderState,{passive:true});
syncHeaderState();

// ── MOBILE MENU ──
function toggleMenu(){const open=mobMenu.classList.toggle('open');document.getElementById('hbg').setAttribute('aria-expanded',open?'true':'false');}
function closeMenu(){mobMenu.classList.remove('open');document.getElementById('hbg').setAttribute('aria-expanded','false');}
document.addEventListener('click',e=>{
  if(!nav.contains(e.target)&&!mobMenu.contains(e.target))mobMenu.classList.remove('open');
});

// ── RATE TABS ──
function switchTab(e,brand){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  e.target.classList.add('active');
  const p=document.getElementById('tab-'+brand);
  if(p)p.classList.add('active');
}

// ── REVEAL ON SCROLL ──
let ro;
function initReveal(){
  if(ro)ro.disconnect();
  ro=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');ro.unobserve(e.target);}});
  },{threshold:.12});
  document.querySelectorAll('.reveal:not(.visible)').forEach(el=>ro.observe(el));
}
initReveal();
